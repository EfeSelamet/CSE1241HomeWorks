//Mehmet Efe Selamet 150122058

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

//this is the node structer
struct node
{
    int duration;
    char name[25];
    struct node *next;
};

//this function adds node to linked list to the end
void insertNode(struct node **Node,char song[],int sec)
{
    struct node* new = (struct node*)malloc(sizeof(struct node));
    new->next = NULL;
    new->duration = sec;
    strcpy(new->name,song);

    struct node *current = *Node;
    while(current->next != NULL)
    {
        current = current->next;
    }
    current->next = new;

}

//this function deletes node from the linked list
void deleteNode(struct node **Node,char song[])
{
    struct node *current = *Node;
    struct node *new;
    if(strcmp(current->name,song) == 0)
    {
        new = current->next;
        current->next = NULL;
        current = new;
    }
        
    else
    {    
        while(current != NULL)
        {
            if(strcmp(current->next->name,song) == 0)
            {
                current->next = current->next->next;
                break;
            }
            else
            {
                current = current->next;
            }
        }
    }
}

//this function sorts the linked list in increasing order of song durations
void sort(struct node *start) 
{ 
    int swapped, i; 
    struct node *ptr1; 
    struct node *lptr = NULL; 
  
    if (start == NULL) 
        return; 
  
    do
    { 
        swapped = 0; 
        ptr1 = start; 
  
        while (ptr1->next != lptr) 
        { 
            if (ptr1->duration > ptr1->next->duration) 
            { 
                int temp = ptr1->duration; 
                ptr1->duration = ptr1->next->duration; 
                ptr1->next->duration = temp;

                char temp2[25];
                strcpy(temp2,ptr1->name);
                strcpy(ptr1->name,ptr1->next->name);
                strcpy(ptr1->next->name,temp2); 
                swapped = 1; 
            } 
            ptr1 = ptr1->next; 
        } 
        lptr = ptr1; 
    } 
    while (swapped); 
}

//this function prints the linked list
void printList(struct node *Node)
{   
    sort(Node);
    struct node *current = Node;
    int i = 0;
    printf("List in duration time order: \n");
    while(current->next != NULL)
    {   
        printf("%d. ",++i);
        printf("%s  ",current->name);
        int min = current->duration/60;
        int sec = current->duration%60;
        printf("%d:%d\n",min,sec);
        current = current->next;
    }
}

int main()
{

    FILE *file = fopen("songs.txt","r");
    char arr[50];
    char ch[25];

    struct node *node1 = malloc(sizeof(struct node));
    node1->next = NULL;

    int minute = 0;
    int second = 0;
    int total = 0;
    
    //this while loop gets the song names and song duration from file and creates a linked list
    while(fgets(arr,50,file))
    {
        for(int i = 0;arr[i] != '\0';i++)
        {
            if(arr[i] == 9)
            {   
                int j;
                for(j = 0;j < i;j++)
                {
                    ch[j] = arr[j];
                }
                ch[j] = '\0';

                minute = (arr[i+1]-'0')*10 + arr[i+2]-'0';
                second = (arr[i+4]-'0')*10 + arr[i+5]-'0';
                total = minute*60 + second;

                insertNode(&node1,ch,total);   
                break;
            }
        }
    }

    printList(node1);

    
    int end = 1;
    while(end)
    {   
        printf("Enter your choice:\n");
        printf("1 to insert a song into the list.\n");
        printf("2 to delete a song from the list.\n");
        printf("3 to print the songs in the list.\n");
        printf("4 to print the songs to an output file.\n");
        printf("5 to end.\n");
        char choice[1];
        //After this gets function for some reason data inside the node1 and linked list gets deleted because of that i have to recreate node1 and linked list
        gets(choice);


            char arr[50];
            char ch[25];

            struct node *node1 = malloc(sizeof(struct node));
            node1->next = NULL;

            int minute = 0;
            int second = 0;
            int total = 0;
    
            while(fgets(arr,50,file))
            {
                for(int i = 0;arr[i] != '\0';i++)
                {
                    if(arr[i] == 9)
                    {   
                        int j;
                        for(j = 0;j < i;j++)
                        {
                            ch[j] = arr[j];
                        }
                        ch[j] = '\0';

                        minute = (arr[i+1]-'0')*10 + arr[i+2]-'0';
                        second = (arr[i+4]-'0')*10 + arr[i+5]-'0';
                        total = minute*60 + second;

                        insertNode(&node1,ch,total);   
                        break;
                    }
                }
            }

        //inside if block a song is add to the list
        if(choice[0] == '1')
        {   
            printf("Enter a song name with duration: \n");
            char input[50];
            gets(input);
            char ch2[25];
            
            
            for(int i = 0;input[i] != '\0';i++)
            {
                if(input[i] == 9)
                {   
                    int j;
                    for(j = 0;j < i;j++)
                    {
                        ch2[j] = input[j];
                    }
                    ch2[j] = '\0';

                    minute = (input[i+1]-'0')*10 + input[i+2]-'0';
                    second = (input[i+4]-'0')*10 + input[i+5]-'0';
                    total = minute*60 + second;

                    insertNode(&node1,ch2,total);   
                    break;
                }
            }
            printList(node1);
        }

        //inside this else if block a song is deleted from the list
        else if(choice[0] == '2')
        {
            printf("Enter song name: ");
            char input2[50];
            gets(input2);

            deleteNode(&node1,input2);
            printList(node1);
        }

        //inside this else if block the list is being printed
        else if(choice[0] == '3')
        {
            
            printList(node1);
        }

        //inside this else if block the list is printed to the output file
        else if(choice[0] == '4')
        {   
            printf("Enter a file name: ");
            char fileName[25];
            gets(fileName);
            FILE *output = fopen(fileName,"w");
            sort(node1);
            struct node *current = node1;
            printf("List in duration time order: \n");
            int i = 0;
            while(current->next != NULL)
            {
                int min = current->duration/60;
                int sec = current->duration%60;
                fprintf(output,"%d.%s  %d:%d\n",++i,current->name,min,sec);   
                current = current->next;
            }
        }
        //inside this else if block the program is ended
        else if(choice[0] == '5')
        {
            printf("Bye-bye");
            end = 0;
            break;
        }
    }
}
