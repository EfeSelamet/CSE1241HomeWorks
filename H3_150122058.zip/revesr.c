#include <stdio.h>
//150122058

//the functşon for reversing the numbers last N digit
void reverseN(int *number , int N)
{
    int sum = 0;
    int a ,j ,i,l;
    int n = *number;
    //this for loop reverses the last N digit
    for(i = 1,j = N;i <= N;i++)
    {
        a = n%10;
        n = n/10;
        sum = (sum*10) + a;
    }

    for(l = 0;l < N;l++)
     {
        n = n*10;
    }
    sum = n + sum;
     printf("%d",sum);
}
int main()
{
    int Number;
    int *number = &Number;
    int N;
    //gets the number and the last N digits from th user
    printf("Enter your number an last N digits: ");
    scanf("%d",&Number);
    scanf("%d",&N);

    int n = Number;
    int i = 0;
    //this while loop and the if else checks if the number has more digits than the user has entered
    while(n >= 1)
    {
        n = n/10;
        i++;
    }
    if(i >= N)
    {
        reverseN(number,N);
    }
    else
    {
        printf("N cannot be bigger than %d",i);
    }
    return 0;
}
