#include <stdio.h>
//150122058 Mehmet Efe Selamet

//this function uses itartion to calculate the weight on the performers back
double calculateWeightBack1(int row ,int col)
{
    int i;
    double weight[row][col];
    int j;
    weight[0][0] = 0.0;
    for(i = 1;i <= row;i++)
    {   
        weight[i][0] = (weight[i-1][0] + 80.0)/2.0;
        weight[i][i] = (weight[i-1][i-1] + 80.0)/2.0;
        for(j = 1;j < i;j++)
        { 
            weight[i][j] = (weight[i-1][j-1]+80.0)/2.0 + (weight[i-1][j]+80.0)/2.0;
        }
    }
    return weight[row][col];
}
//this function calculates the weight on the back of the perfomers by using recursion
double calculateWeightBack2(int row ,int col)
{   
     //this block of code calculates the ones who is column number is zero
    if(col == 0)
    {   
        if(0 < row)
        {
            return (calculateWeightBack2(row-1,col) + 80.0)/2.0;
        }
    }
    //this this block of code calculates the ones who is column number is equal to the row number
    else if(col == row)
    {
        return (calculateWeightBack2(row-1,col-1) + 80.0)/2.0;
    }
    //thşs block of calculates the rest of the perfomers
    else if(col > 0 || col < row)
    {
        if(0 < row)
        {
            return ((calculateWeightBack2(row-1,col-1) + 80.0)/2.0 + (calculateWeightBack2(row-1,col) + 80.0)/2.0);
        }
    }
}

int main()
{
    int row;
    int col;
    printf("Enter row and column of the person: ");
    
    scanf("%d",&row);
    scanf("%d",&col);

    double result1 = calculateWeightBack1(row,col);
    double result2 = calculateWeightBack2(row,col);
    printf("%.2f\n",result1);
    printf("%.2f",result2);
    return 0;
}