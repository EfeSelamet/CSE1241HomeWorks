//Mehmet Efe Selamet 150122058
import java.util.ArrayList;

//this isthe ShoppingMall class
public class ShoppingMall {
	//creates the items arraylist
	private ArrayList<Item> items = new ArrayList<Item>();
	
	//this method returns the objects inside the items arraylist
	public ArrayList<Item> getItems(){
		return items;
	}
	//this method adds a deafult dairy object to the arraylist
	public void addDairy() {
		Dairy dairy = new Dairy();
		items.add(dairy);
	}
	//this method adds a default Fruit object to the arraylist
	public void addFruit() {
		Fruit fruit = new Fruit();
		items.add(fruit);
	}
	//this method adds a default Top object to the arraylist
	public void addTop() {
		Top top = new Top();
		items.add(top);
	}
	//this method adds a default Trousers object to the arraylist
	public void addTrousers() {
		Trousers trousers= new Trousers();
		items.add(trousers);
	}
	//thid method adds a default Underware object to the arraylist
	public void addUnderware() {
		Underware underware = new Underware();
		items.add(underware);
	}
	//this method adds a default Vegetable object to the arraylist
	public void addVegetable() {
		Vegetable vegetable = new Vegetable();
		items.add(vegetable);
	}
	//this method adds an object of the users choice
	public void addArbitrary(Item item) {
		items.add(item);
	}
	//this method calculates and returns the total bill
	public double bill() {
		double total = 0;
		for(Item item : items) {
			total += item.calculatePrice();
		}
		return total;
	}
}
