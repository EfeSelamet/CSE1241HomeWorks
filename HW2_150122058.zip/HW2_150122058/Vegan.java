//Mehmet Efe Selamet 150122058
//This id the vegan interface and the madeOf method

public interface Vegan {
	public void madeOf();
}
