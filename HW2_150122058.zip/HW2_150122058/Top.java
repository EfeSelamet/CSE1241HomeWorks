//Mehmet Efe Selamet 150122058

//this is the Top class that extends Colthing 
public class Top extends Clothing{
	//this constructer calls the other construccter
	public Top() {
		this(20.0);
	}
	//this constructer creats a Top objcet
	public Top(double basePrice) {
		this.basePrice = basePrice;
	}
	
	//this method prints out how to wash the object
	@Override
	public void howToWash() {
		System.out.println("Wash Top at 40 degrees.");	
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*120;
		return price;
	}
}
