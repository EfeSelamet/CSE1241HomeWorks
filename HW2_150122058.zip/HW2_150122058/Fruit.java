//Mehmet Efe Selamet 150122058

//This is the fruit class that extends Food and implements Vegan and Washable
public class Fruit extends Food implements Vegan , Washable{
	//this constructer calls the other constructer
	public Fruit() {
		this(6.0);
	}
	//this constructer creates a Fruit object
	public Fruit(double basePrice) {
		this.basePrice = basePrice;
	}
	//this method prints out how to wash the object
	@Override
	public void howToWash() {
		System.out.println("Wash Fruit with cold water.");
	}
	//this method prints out what is the object made out of
	@Override
	public void madeOf() {
			System.out.println("It is made only of fruits.");
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*120;
		return price;
	}
}
