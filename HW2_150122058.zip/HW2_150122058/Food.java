//Mehmet Efe Selamet 150122058

//this is the Food abstract class that extendes Item
public abstract class Food extends Item{
	//this constructer sets vat to 0.08
	public Food() {
		vat = 0.08;
	}
}
