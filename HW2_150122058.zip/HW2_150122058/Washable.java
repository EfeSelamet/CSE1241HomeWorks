//Mehmet Efe Selamet
//this is the washable interface and howToWash method

public interface Washable {
	public void howToWash();
}
