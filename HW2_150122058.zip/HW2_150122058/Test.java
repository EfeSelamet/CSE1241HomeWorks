//Mehmet Efe Selamet 150122058
import java.util.ArrayList;

//test class to test if the classes and the interfaces working properly
public class Test {
	public static void main(String[] args) {
		//creates a ShoppingMall and a Top object 
		ShoppingMall shop = new ShoppingMall();
		Top top = new Top(100);
		
		//adds the objects to the arraylist
		shop.addDairy();
		shop.addFruit();
		shop.addTop();
		shop.addTrousers();
		shop.addUnderware();
		shop.addVegetable();
		shop.addArbitrary(top);
		
		//calls the methods
		printContent(shop);
		printWashingInstructions(shop);
		//prints out the bill
		System.out.printf("Your total is: %4.2f$",shop.bill());
	}
	//prints the content of the Vegan objects
	public static void printContent(ShoppingMall shop) {
		for (Item item : shop.getItems()) {
			if (item instanceof Fruit){
				((Fruit)item).madeOf();
			}
			else if(item instanceof Vegetable) {
				((Vegetable)item).madeOf();
			}
		}
	}
	//print how to wash the washable objects
	public static void printWashingInstructions(ShoppingMall shop) {
		for (Item item : shop.getItems()) {
			if (item instanceof  Top) {
				((Top)item).howToWash();
			}
			else if(item instanceof Trousers) {
				((Trousers)item).howToWash();
			}
			else if(item instanceof Underware) {
				((Underware)item).howToWash();
			}
			else if(item instanceof Fruit) {
				((Fruit)item).howToWash();
			}
			else if(item instanceof Vegetable) {
				((Vegetable)item).howToWash();
			}
		}
	}
}
