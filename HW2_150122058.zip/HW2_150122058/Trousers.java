//Mehmet Efe Selamet 150122058

//this is the Trousers class that extends Clothig
public class Trousers extends Clothing {
	//this constructer calls the other constructer
	public Trousers() {
		this(40.0);
	}
	//this constructer creates a Trousers object
	public Trousers(double basePrice) {
		this.basePrice = basePrice;
	}
	
	//this method prints out how to wash the object
	@Override
	public void howToWash() {
		System.out.println("Wash Trousers at 30 degrees.");
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*120;
		return price;
	}
}
