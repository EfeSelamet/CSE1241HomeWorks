//Mehmet Efe Selamet 150122058

//this is the Dairy class that extends the Food abstract class
public class Dairy extends Food{
	//this constructer calls the other constructer
	public Dairy() {
		this(8.0);
	}
	//this constructer creates a dairy object
	public Dairy(double basePrice) {
		this.basePrice = basePrice;
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*130;
		return price;
	}
}
