//Mehmet Efe Selamet 150122058

//this is the underware class that extends Clothing
public class Underware extends Clothing{
	//this constructer calls the other constructer
	public Underware() {
		this(30.0);
	}
	//this constructer creates an Underware object 
	public Underware(double basePrice) {
		this.basePrice = basePrice;
	}
	
	//this method prints out how to wash the object
	@Override
	public void howToWash() {
		System.out.println("Wash Underware at 60 degrees.");
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*145;
		return price;
	}
	
}
