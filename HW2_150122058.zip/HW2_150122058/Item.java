//Mehmet Efe Selamet 150122058

//this is the Item abstract class 
public abstract class Item {
	double vat;
	double basePrice;
	
	//this method allows to return vat variable
	public double getVat() {
		return vat;
	}
	//this method allows the user to set vat variable
	public void setVat(double vat) {
		this.vat = vat;
	}
	//this method allows to return basePrice variable
	public double getBasePrice() {
		return basePrice;
	}
	//this method allows the user to set basePrice variable
	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}
	
	//this abstract method makes that all the subclasses of this class to have this method implemented
	public abstract double calculatePrice();
}
