//Mehmet Efe Selamet 150122058

//this is the Vegetable class that extends Food and implements Vegan and Washable
public class Vegetable extends Food implements Vegan , Washable{
	//this constructer calls the other constructer
	public Vegetable(){
		this(10.0);
	}
	//this constructer creates the Vegetable object
	public Vegetable(double basePrice){
		this.basePrice = basePrice;
	}
	
	//this method prints out how to wash the object
	@Override
	public void howToWash() {
		System.out.println("Wash Vegetable with  warm water.");
	}
	//this method prints out what is the object made out of
	@Override
	public void madeOf() {
		System.out.println("It is made only of vegetables.");	
	}
	//this method calculates the price of the object
	@Override
	public double calculatePrice() {
		double price;
		price = ((basePrice + basePrice*vat)/100)*125;
		return price;
	}
}
