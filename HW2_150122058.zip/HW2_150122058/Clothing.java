//Mehmet Efe Selamet 150122058

//this is the Clothing abstract class that extends Item and implements Washable
public abstract class Clothing extends Item implements Washable {
	//this constructer sets vat to 0.18
	public Clothing() {
		vat = 0.18;
	}
}
