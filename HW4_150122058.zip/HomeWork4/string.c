//150122058 Mehmet Efe Selamet
//I used VScode to run my program and used wingw64 as my compiler

#include<stdio.h>
#include<string.h>

//this is the String structer
struct String
{
    char string[50];
    int length;
};

//this function returns the character in the given index
int charAt(struct String *s,int index)
{   
    if(index < s->length)
    {
        return (s->string)[index];
    }    
    else
    {
       return -1;
    }
}

//this function adds two String to eachother
struct String *concat(struct String *s1,struct String *s2)
{
    struct String *str;
    char arr1[50];
    char arr2[50];
    char arr[50];
    int i,j;
    strcpy(arr1,s1->string);
    strcpy(arr2,s2->string);

    for(i = 0;arr1[i] != '\0';i++)
    {
        arr[i] = arr1[i];
    }
    for(j = 0;arr2[j] != '\0';j++,i++)
    {
        arr[i] = arr2[j];
    }
    arr[i+1] = '\0';

    strcpy(str->string,arr);
    return str;
}

//this function is for searching the string
unsigned int strSearch(struct String *s1, struct String *s2)
{
    int result = 0;
    int bool = 0;
    for(int i = 0;s1->string[i] != '\0';i++)
    {
        for(int j = 0;s2->string[j] != '\0';j++)
        {
            if(s1->string[i] == s2->string[j])
            {
                bool = 1;
                result++;
                break;
            }
        }
        if(bool == 0)
        {
            break;
        }
    }
    return result;
}

//this function calculates the score of the string
unsigned int findScore(struct String *s1)
{
    int result = 0;
    for(int i = 0;s1->string[i] != '\0';i++)
    {
        switch(s1->string[i]){ 
            case 'A':       
            case 'a': result += 1;break;
            case 'E':
            case 'e': result += 1;break;
            case 'I':
            case 'i': result += 1;break;
            case 'O':
            case 'o': result += 1;break;
            case 'U':
            case 'u': result += 1;break;
            case 'L':
            case 'l': result += 1;break;
            case 'N':
            case 'n': result += 1;break;
            case 'R':
            case 'r': result += 1;break;
            case 'S':
            case 's': result += 1;break;
            case 'T':
            case 't': result += 1;break;
            case 'D':
            case 'd': result += 2;break;
            case 'G':
            case 'g': result += 2;break;
            case 'B':
            case 'b': result += 3;break;
            case 'C':
            case 'c': result += 3;break;
            case 'M':
            case 'm': result += 3;break;
            case 'P':
            case 'p': result += 3;break;
            case 'F':
            case 'f': result += 4;break;
            case 'H':
            case 'h': result += 4;break;
            case 'V':
            case 'v': result += 4;break;
            case 'W':
            case 'w': result += 4;break;
            case 'Y':
            case 'y': result += 4;break;
            case 'K':
            case 'k': result += 5;break;
            case 'J':
            case 'j': result += 8;break;
            case 'X':
            case 'x': result += 8;break;
            case 'Q':
            case 'q': result += 10;break;
            case 'Z':
            case 'z': result += 10;break;
        }
    }
    return result;
}

int main()
{   
    struct String string1;
    struct String string2;
    char arr[50];

    //these codes get the file names from the user
    printf("Enter the input and output file name: \n");
    char input[50];
    char output[50];
    scanf("%s",input);
    scanf("%s",output);

    //opens the files
    FILE *inputf = fopen(input,"r");
    FILE *outputf = fopen(output,"w");

    int i,j,k,l,m,n,o;
    int word = 0;
    int letters = 0;
    int index;
    //this while loop allows the program to read from file line by line
    while(fgets(arr,50,inputf))
    {   
        //this if block ends the program if the program reads "exit" from file
        //the program will also end if there is no lines left to read
        if(strcmp(arr,"exit\n") == 0 || strcmp(arr,"exit") == 0)
        {
            printf("\nBye-bye");
            fprintf(outputf,"\nBye-bye");
            break;
        }
        //this else if block prints the word count and letter count
        else if(strcmp(arr,"stat") == 0|| strcmp(arr,"stat\n") == 0)
        {
            printf("\nTotal words are: %d",word);
            printf("\nTotal letters are: %d",letters);
            fprintf(outputf,"\nTotal words are: %d",word);
            fprintf(outputf,"\nTotal letters are: %d",letters);
        }
        else
        {
            for(j = 0;arr[j] != '\0';j++)
            {
                if(arr[j] == ':')
                {   
                    //this switch case is for determining which function to use
                    switch(arr[j+1])
                    {   
                        //this case invokes charAt function
                        case '1':
                        //sets the first string
                        for(l = 0;l < j;l++)
                        {
                            string1.string[l] = arr[l];
                        }
                        string1.string[l] = '\0';
                        string1.length = l;
                        index = 0;
                        //stes the index
                        for(k = j+3;arr[k] != '\0';k++)
                        {
                            if(arr[k] >= '0' && arr[k] <= '9')
                            {
                                index = index * 10;
                                index = index + (arr[k]-'0');
                            }    
                        }
                        //if return value is -1 prints -1
                        if(charAt(&string1,index) != -1)
                        {
                            printf("\n%c",charAt(&string1,index));
                            fprintf(outputf,"%c",charAt(&string1,index));
                        }
                        //if return value is a character prints the character
                        else
                        {
                            printf("\n%d",charAt(&string1,index));
                            fprintf(outputf,"%d",charAt(&string1,index));
                        }
                        break;

                        //this case for concatenating strings
                        case '2':
                        word++;
                        //sets the string 
                        for(l = 0;l < j;l++)
                        {
                            string1.string[l] = arr[l];
                        }
                        string1.string[l] = '\0';
                        string1.length = l;
                        //sets the second string
                        for(k = j + 3,l = 0;arr[k] != '\0';k++,l++)
                        {
                            string2.string[l] = arr[k];
                        }
                        string2.string[l] = '\0';
                        string2.length = l;
                        //prints the concatenated string
                        printf("\n%s",concat(&string1,&string2)->string);
                        fprintf(outputf,"\n%s",concat(&string1,&string2)->string);
                        break;

                        //this case is foe string search
                        case '3':
                        //for total word counts the word after the ':'
                        word++;
                        //this for loop is to find the string that has the characters from the string 
                        for(m = 0;arr[m] != '\0';m++)
                        {   
                            //checks for ' ' of ':' for string dividing
                            if(arr[m] == ' ' || arr[m] == ':')
                            {   
                                //sets the first string
                                for(l = 0;l < m-n;l++)
                                {
                                    string1.string[l] = arr[l+n];
                                }
                                string1.string[l] = '\0';
                                string1.length = l;
                                //sets the second string
                                for(k = j + 3,l = 0;arr[k] != '\0';k++,l++)
                                {
                                    string2.string[l] = arr[k];
                                }
                                string2.string[l] = '\0';
                                string2.length = l;
                                //checks if there is a match
                                if(strSearch(&string1,&string2) != 0)
                                {
                                    printf("\n%d",strSearch(&string1,&string2));
                                    fprintf(outputf,"\n%d",strSearch(&string1,&string2));
                                    break;
                                }
                                else
                                {
                                    n = m+1;
                                    continue;
                                }
                            } 
                        }
                        break;

                        //this case is for calculating the score
                        case '4':
                        //sets the string
                        for(l = 0;l < j;l++)
                        {
                            string1.string[l] = arr[l];
                        }
                        string1.string[l] = '\0';
                        string1.length = l;
                        //prints the string
                        printf("\n%d",findScore(&string1));
                        fprintf(outputf,"\n%d",findScore(&string1));
                        break;

                        default:
                        printf("invalde input");
                        fprintf(outputf,"invalde input");
                        break;
                    }
                }
                //counts the total word count
                if(arr[j] == ' ' || arr[j] == '\n')
                {
                    word++;
                }
                //counts the total letter caount
                if(arr[j] >= 65 && arr[j] <= 90 || arr[j] >= 97 && arr[j] <= 122)
                {
                    letters++;
                }
            }
        }    
    }
    fclose(inputf);
    fclose(outputf);
}
