//Mehmet Efe Selamet 150122058
public class Mammal extends Animal {
	//Mammal class constructer
	public Mammal(String name,int age) {
		super(name,age);
	}
	
	//walk method
	public void walk() {
		System.out.print("I can walk to the far away lands!\n");
	}
	//reproduction method
	@Override
	public void reproduce() {
		System.out.println("I give birth!");
	}
	//eatibg habit method
	public void herbivore() {
		System.out.println("I eat plants only!");
	}
}
//Donkey subclass
class Donkey extends Mammal{
	private static int count;
	
	//Donkey class construcer
	public Donkey(String name,int age) {
		super(name,age);
		setLegNumber(4);
		setPregnancy(1);
		setOffsprings(1);
		count++;
	}
	//Greeting method
	@Override
	public void sayGreeting() {
		System.out.println("Life will go on as it has always gone that is, badly!");
	}
	//returns the number of donkeys
	public static int getCount() {
		return count;
	}
	//decrements the number of donkeys by one 
	public static void decrementCount() {
		count--;
	}
}
//Horse subclass
class Horse extends Mammal{
	private static int count;
	//Horse class constructer
	public Horse(String name,int age) {
		super(name,age);
		setLegNumber(4);
		setPregnancy(1);
		setOffsprings(1);
		count++;
	}
	//Greeting method
	@Override
	public void sayGreeting() {
		System.out.println("I will work harder!");
	}
	//returns the number of horses
	public static int getCount() {
		return count;
	}
	//decrements the number of horses by one
	public static void decrementCount() {
		count--;
	}
}
//pig subclass
class Pig extends Mammal{
	private static int count;
	//Pig class constructer
	public Pig(String name,int age) {
		super(name,age);
		setLegNumber(4);
		setPregnancy(1);
		setOffsprings(1);
		count++;
	}
	//Greeting method
	@Override
	public void sayGreeting() {
		System.out.println("“All animals are equal, but some animals are more equal than others!");
	}
	//returns the number of Pigs
	public static int getCount() {
		return count;
	}
	//deccremnts the number of Pigs by one
	public static void decrementCount() {
		count--;
	}
}
//Sheep subclass
class Sheep extends Mammal{
	private static int count;
	//Sheep class constructer
	public Sheep(String name,int age) {
		super(name,age);
		setLegNumber(4);
		setPregnancy(1);
		setOffsprings(1);
		count++;
	}
	//Gretting method
	@Override
	public void sayGreeting() {
		System.out.println("Four legs good, two legs better!");
	}
	//returns the number of Sheep
	public static int getCount() {
		return count;
	}
	//decrements the number of sheep by one
	public static void decrementCount() {
		count--;
	}
}