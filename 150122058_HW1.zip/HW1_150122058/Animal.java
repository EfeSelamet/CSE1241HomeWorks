//Mehmet Efe Selamet 150122058
import java.util.ArrayList;

public class Animal {
	//declairing variables
	private String name;
	private int legNumber;
	private int age;
	private int pregnancyPerYear;
	private int numberOfOffsprings;
	
	//Animal constructer
	public Animal(String name,int age) {
		this.name = name;
		this.age = age;
	}
	//Greet method
	public void sayGreeting() {
		System.out.println("Have nothing to say!");
	}
	//reproduction method
	public void reproduce() {
		System.out.println("None of your business!!");
	}
	//toString method
	public String toString() {
		return "My name is " + name + "." +
			"\nI am " + age + " years old." +
			"\nI have " + legNumber + " legs.";
	}
	//getters and setters for private variables
	public void setLegNumber(int legNumber) {
		this.legNumber = legNumber;
	}
	public int getLegNumber() {
		return legNumber;
	}
	public void setPregnancy(int pregnancyPerYear) {
		this.pregnancyPerYear = pregnancyPerYear;
	}
	public int getPregnancy() {
		return pregnancyPerYear;
	}
	public void setOffsprings(int numbeOfOffsprings) {
		this.numberOfOffsprings = numberOfOffsprings;
	}
	public int getOffsprings() {
		return numberOfOffsprings;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
}
