//Mehmet Efe Selamet 150122058

//importing 
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

//AnimalFamr class
public class AnimalFarm{
	//implementation of animalList animalNames CAPACITY and numberOfAnimals
	private ArrayList<Animal> animalList = new ArrayList<Animal>();
	private ArrayList<String> animalNames = new ArrayList<String>();
	private final int CAPACITY;
	private int numberOfAnimals = 0;
	
	//AnimalFarm constructer
	public AnimalFarm(int CAPACITY) {
		this.CAPACITY = CAPACITY;
	}
	//returns the number of animals
	public int getNumberOfAnimals() {
		return numberOfAnimals;
	}
	//adds animal to the the animalList and animalNames
	//checks if the farm has the capacity to add another animal
	public boolean addAnimal(Animal animal) throws IllegalNameException {
		if(numberOfAnimals == CAPACITY) {
			return false;
		}
		else{
			//checks if there is another animal with the same name
			if(animalNames.contains(animal.getName())) {
				throw new IllegalNameException("This name is already given to another animal!");
			}
			//adds the animals to the animalList and animalNames
			else {
				animalNames.add(animal.getName());
				animalList.add(animal);
				numberOfAnimals++;
				return true;
			}	
		}
	}
	//removes animal from animalList and animalNames
	public boolean removeAnimal(String name) {
		boolean result = false;
		int index = animalNames.indexOf(name);
		//finds the object with the name
		for ( Animal animal : animalList) {
	        if (name.equals(animal.getName())) {
	        	//checks if the object is a horsee
	            if(animal instanceof Horse) {
	            	Horse.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	            //checks if the object is a chicken
	            else if(animal instanceof Chicken) {
	            	Chicken.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	            //checks if the object is a raven
	            else if(animal instanceof Raven) {
	            	Raven.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	            //checks if the object is a sheep
	            else if(animal instanceof Sheep) {
	            	Sheep.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	            //checks if the object is a pig
	            else if(animal instanceof Pig) {
	            	Pig.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	            //checks if the object is a donkey
	            else if(animal instanceof Donkey) {
	            	Donkey.decrementCount();
	            	animalNames.remove(index);
	            	animalList.remove(index);
	            	result = true;
	            }
	        }
		}
		return result;
	}
	//retruns a single animal greeting
	public void printOneAnimalGreeting(Animal animal) {
		animal.sayGreeting();
	}
	//returns all the animals greetings
	public void printAllAnimalGreetings() {
		for(Animal animal : animalList) {
			printOneAnimalGreeting(animal);
		}
	}
	//returns a singel animals name
	public void printOneAnimalName(Animal animal) {
		animal.getName();
	}
	//returns all animals names
	public void printAllAnimalNames() {
		for(Animal animal : animalList) {
			printOneAnimalName(animal);
		}
	}
	//prints all the animals
	public void printAllAnimal() {
		for(Animal animal : animalList) {
			animal.toString();
		}
	}
	//calculates and returns the next years population
	public int nextYearPopulationForecast() {
		int result = 0;
		for(Animal animal : animalList) {
			result += animal.getOffsprings() * animal.getPregnancy() + 1;
		}
		return result;
	}
	//returns the animal movements
	public void animalMovements() {
		for(Animal animal : animalList) {
			//checks if the object is a bird
			if(animal instanceof Bird) {
				System.out.println("My name is" + animal.getName() + " and ");
				((Bird) animal).fly();
			}
			//chaecks if the object is mammal
			else if(animal instanceof Mammal) {
				System.out.println("My name is" + animal.getName() + " and ");
				((Mammal) animal).walk();
			}
		}
	}
	//returns the animals eating habits
	public void eatingHabits() {
		for(Animal animal : animalList) {
			//checks is the object is a bird
			if(animal instanceof Bird) {
				System.out.println("My name is" + animal.getName() + " and ");
				((Bird) animal).omnivore();
			}
			//checks if the object is a mammal
			else if(animal instanceof Mammal) {
				System.out.println("My name is" + animal.getName() + " and ");
				((Mammal) animal).herbivore();
			}
		}
	}
	//sorts the animals in alpahbetical order
	public void sortAlphabetically() {
		String temp;
		String[] array = new String[numberOfAnimals];
		int i = 0;
		//puts the animal names in to a array
		for(Animal animal : animalList) {
			array[i] = animal.getName();
			i++;
		}
		//sorts the array
		for(int j = 0;j < array.length;j++) {
			for(int k = 0;k < array.length;k++) {
				if(array[j].compareTo(array[k]) > 0) {
					temp = array[j];
					array[j] = array[i];
					array[i] = temp;
				}
			}
		}
		//prints the array
		for(int j = 0;j < array.length;j++) {
			System.out.println(array[j]);
		}
	}
	//sorts the animals based on theis number of legs
	public void sortBasedOnLegNumer() {
		Animal temp;
		ArrayList<Animal> animalList2 = new ArrayList<Animal>();
		//puts the animals in to another arraylist
		for(Animal animal : animalList) {
			animalList2.add(animal);
		}
		//sorts the arraylist based on their leg number
		for(Animal animal : animalList2) {
			for(Animal animal2 : animalList2) {
				if(animal.getLegNumber() > animal2.getLegNumber()) {
					temp = animal;
					animal = animal2;
					animal2 = temp;
				}
			}
		}
		//displays the sorted arraylist
		for(Animal animal : animalList2) {
			System.out.println(animal.getName() + "  has " + animal.getLegNumber() + " legs!");
		}
	}
	//sorts the animals based on their age
	public void sortBasedOnAge() {
		Animal temp;
		ArrayList<Animal> animalList2 = new ArrayList<Animal>();
		//puts the animals in to another arraylist
		for(Animal animal : animalList) {
			animalList2.add(animal);
		}
		//sorts the arraylist based on their age
		for(Animal animal : animalList2) {
			for(Animal animal2 : animalList2) {
				if(animal.getAge() > animal2.getAge()) {
					temp = animal;
					animal = animal2;
					animal2 = temp;
				}
			}
		}
		//displayes the sorted arraylist
		for(Animal animal : animalList2) {
			System.out.println(animal.getName() + "  is " + animal.getAge() + " years old!");
		}
	}
	//sorts the animals based on their oredr that they gpt added to the arraylist
	public void sortBasedOnDate() {
		for(Animal animal : animalList) {
			System.out.println(animal.getName());
		}
	}
	//searches the arraylist an returns the animal based on the name
	public void searchBasedOnName(String name) {
		for(Animal animal : animalList) {
			if(name.equals(animal.getName())) {
				animal.toString();
			}
		}
	}
	//searches the arraylist and retruns the animal based on age
	public void searchBasedOnAge(int age) {
		for(Animal animal : animalList) {
			if(age == animal.getAge()) {
				System.out.println(animal.getName() + " is " + age + " years old!");
			}
		}
	}
	//prints the report on the given file
	public void printReport(String fileName) throws FileNotFoundException{
		java.io.File file = new java.io.File(fileName);
		if(!file.exists()) {
			System.out.println("This file does not exist!");
			System.exit(0);
		}
		try(java.io.PrintWriter printer = new java.io.PrintWriter(fileName);) {
			printer.print("\nWe have a total of " + numberOfAnimals + " animals in the farm.\n");
			if(Chicken.getCount() > 0) {
				printer.print(Chicken.getCount() + " of them are chicken. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Chicken) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
			if(Raven.getCount() > 0) {
				printer.print(Raven.getCount() + " of them are Raven. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Raven) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
			if(Donkey.getCount() > 0) {
				printer.print(Donkey.getCount() + " of them are Donkey. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Donkey) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
			if(Horse.getCount() > 0) {
				printer.print(Horse.getCount() +  "of them are Horse. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Horse) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
			if(Pig.getCount() > 0) {
				printer.print(Pig.getCount() + "of them are Pig. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Pig) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
			if(Sheep.getCount() > 0) {
				printer.print(Sheep.getCount() + "of them are Sheep. Those are: \n");
				printer.printf("%-15s%-15s%-15s%n","Name","Age","Leg Number");
				for(Animal animal : animalList) {
					if(animal instanceof Sheep) {
						printer.printf("%-15s%-15s%-15s%n",animal.getName(),animal.getAge(),animal.getLegNumber());
					}
				}
			}
		}
	}
}
//Exception
class IllegalNameException extends Exception{
	public IllegalNameException(String message) {
		super(message);
	}
}
