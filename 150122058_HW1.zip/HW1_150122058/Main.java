//Mehmet Efe Selamet 150122058
import java.util.Scanner;
import java.io.FileNotFoundException;
//Main class
public class Main {
	public static void main(String[] args)throws IllegalNameException, FileNotFoundException{
		Scanner scanner = new Scanner(System.in);
		int input;
		int capacity;
		//initialze the capacity and creats and AnimalFarm object
		System.out.println("Welcome to Animal Farm simulation program!\n"
				 + "Please enter the capacity of the animal farm: ");
		capacity = scanner.nextInt();
		AnimalFarm farm = new AnimalFarm(capacity);
		do {
			//prints the operations
			System.out.println("0 - Exit the program\n"
					         + "1 - Add animal\n"
					         + "2 - Remove animal\n"
					         + "3 - Search animal\n"
					         + "4 - Sort animal\n"
					         + "5 - Calculate next year's population estimate\n"
					         + "6 - Print all animal's movements\n"
					         + "7 - Print all animal's eating habits\n"
					         + "8 - Print report\n"
					         + "Please enter your choice: ");
			input = scanner.nextInt();
			//this is the add animal operation
			if(input == 1) {
				System.out.println("1 - Chicken\n"
						         + "2 - Donkey\n"
						         + "3 - Horse\n"
						         + "4 - Pig\n"
						         + "5 - Raven\n"
						         + "6 - Sheep\n"
						         + "Select animal type: ");
				int animalType = scanner.nextInt();
				if(animalType <= 6 || animalType > 0) {
					System.out.println("Enter the name");
					String animalname = scanner.next();
					System.out.println("Enter the age");
					int animalage = scanner.nextInt();
					switch(animalType) {
					case 1: Chicken chicken = new Chicken(animalname,animalage);
					farm.addAnimal(chicken); break;
					case 2: Donkey donkey = new Donkey(animalname,animalage);
					farm.addAnimal(donkey);break;
					case 3: Horse horse = new Horse(animalname,animalage);
					farm.addAnimal(horse); break;
					case 4: Pig pig = new Pig(animalname,animalage);
					farm.addAnimal(pig); break;
					case 5: Raven raven = new Raven(animalname,animalage);
					farm.addAnimal(raven); break;
					case 6: Sheep sheep = new Sheep(animalname,animalage);
					farm.addAnimal(sheep); break;
					}
				}
				else {
					System.out.println("Invalid Entery!");
					continue;
				}
			}
			//this is the remove animal operation
			else if(input == 2) {
				System.out.println("Which animal would you like to remove: ");
				String name = scanner.next();
				farm.removeAnimal(name);
			}
			//this is the search animal operation
			else if(input == 3) {
				System.out.println("1 - Search based on name\n"
						         + "2 - Search based on age");
				int choice = scanner.nextInt();
				//searches based on name
				if(choice == 1) {
					System.out.println("Enter the name please: ");
					String name = scanner.next();
					farm.searchBasedOnName(name);
				}
				//searches based on age
				else if(choice == 2) {
					System.out.println("Enter the age please:");
					int age = scanner.nextInt();
					farm.searchBasedOnAge(age);
				}
				else {
					System.out.println("Invalid Entery!");
				}
			}
			//this is the sort animal operation
			else if(input == 4) {
				System.out.println("1 - Sort based on name\n"
						         + "2 - Sort based on leg number\n"
						         + "3 - Sort based on age\n"
						         + "4 - Sort based on adition date\n");
				int choice = scanner.nextInt();
				//sorts alphabeticly
				if(choice == 1) {
					farm.sortAlphabetically();
				}
				//sorts based on number of legs
				else if(choice == 2) {
					farm.sortBasedOnLegNumer();
				}
				//sorts based on age
				else if(choice == 3) {
					farm.sortBasedOnAge();
				}
				//sorts based on the additon date
				else if(choice == 4) {
					farm.sortBasedOnDate();
				}
				else {
					System.out.println("Invalid Entery");
				}
			}
			//this is the population opertion
			else if(input == 5) {
				farm.nextYearPopulationForecast();
			}
			//this is the animal movement operation
			else if(input == 6) {
				farm.animalMovements();
			}
			//this is the animal eating habit operaiton
			else if(input == 7) {
				farm.eatingHabits();
			}
			//this operation prints the report to the given filename
			else if(input == 8) {
				System.out.println("Enter filename: ");
				String file = scanner.next();
				farm.printReport(file);
			}
			else if(input == 0) {
				System.out.println("Good bye");
				System.exit(0);
			}
		}while(input != 0);
	}
}
