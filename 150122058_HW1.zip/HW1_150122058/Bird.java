//Mehmet Efe Selamet 150122058

public class Bird extends Animal{
	//Bird constructer
	public Bird(String name,int age){
		super(name,age);
	}
	//fly method
	public void fly() {
		System.out.print("I can fly to the endless skies!\n");
	}
	//reproduction method
	@Override
	public void reproduce() {
		System.out.println("I lay eggs!");
	}
	//eating habit method
	public void omnivore() {
		System.out.println("I can eat everything!");
	}
}

//Chicken subclass
class Chicken extends Bird{
	private static int count;
	
	//Chicken class constructer
	public Chicken(String name, int age) {
		super(name, age);
		setLegNumber(2);
		setPregnancy(1);
		setOffsprings(200);
		count++;
	}
	
	//greeting method
	@Override
	public void sayGreeting(){
		System.out.println("I have nothing to say other than I am against Pigs!");
	}
	//returns the number of chickens
	public static int getCount() {
		return count;
	}
	//decremts the number of chickens by one
	public static void decrementCount() {
		count--;
	}
}
//Raven subclass
class Raven extends Bird{
	private static int count;
	
	//Raven class costructer
	public Raven(String name, int age) {
		super(name, age);
		setLegNumber(2);
		setPregnancy(1);
		setOffsprings(200);
		count++;
	}
	
	//Greet method
	@Override
	public void sayGreeting(){
		System.out.println("“A happy country where we poor animals shall rest forever!");
	}
	//returns the number of ravens
	public static int getCount() {
		return count;
	}
	//decrements the number of ravens by one
	public static void decrementCount() {
		count--;
	}
}
